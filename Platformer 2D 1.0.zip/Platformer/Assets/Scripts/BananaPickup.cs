using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BananaPickup : MonoBehaviour
{
    [SerializeField] AudioClip bananaPickupSFX;

    void OnTriggerEnter2D(Collider2D other) 
    {
        // Checks to see if the player is colliding with the banana. If yes, it will play an audio clip and delete the banana.
        if(other.tag == "Player")
        {
            AudioSource.PlayClipAtPoint(bananaPickupSFX, Camera.main.transform.position);
            Destroy(gameObject);
        }    
    }
}
