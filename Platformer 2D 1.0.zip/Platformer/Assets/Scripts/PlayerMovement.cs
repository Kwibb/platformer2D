using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float walkSpeed = 10.0f;   // SerializeField allows me to edit this value in the Player Movement component in Unity.
    [SerializeField] float jumpSpeed = 5.0f;

    // Initializing required global variables.
    Vector2 moveInput;
    Rigidbody2D rb2d;
    Animator myAnimator;
    CapsuleCollider2D myBodyCollider;
    BoxCollider2D myFeetCollider;

    // Start is called before the first frame update
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        myAnimator = GetComponent<Animator>();
        myBodyCollider = GetComponent<CapsuleCollider2D>();
        myFeetCollider = GetComponent<BoxCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Movement();       
    }

    void OnMove(InputValue value)
    {
        moveInput = value.Get<Vector2>();
    }

    // Using Vector2's instead of the GetAxis() method. The transform.Translate() method causes jittery movement against walls.
    // Instead I will use Unity's InputSystem package, which requires a Vector2.
    void Movement()
    {
        // Calculates the players horizontal movement with a set speed.
        Vector2 playerVelocity = new Vector2(moveInput.x * walkSpeed, rb2d.velocity.y);
        rb2d.velocity = playerVelocity;
        
        // Allows player to jump when space is pressed, and will not let player jump in air multiple times because
        // of the IsTouchingLayers() method.
        if(Input.GetKeyDown("space") && myFeetCollider.IsTouchingLayers(LayerMask.GetMask("Ground")))
        {  
            rb2d.velocity = Vector2.up * jumpSpeed;
        }

        bool playerMoving = Mathf.Abs(rb2d.velocity.x) > Mathf.Epsilon;
        myAnimator.SetBool("isRunning", playerMoving);  

        // Calls flip sprite method.
        FlipSprite();
    }

    // Calculates how to flip the character sprite in correct direction using Mathf
    void FlipSprite()
    {
        bool playerMoving = Mathf.Abs(rb2d.velocity.x) > Mathf.Epsilon;

        if(playerMoving)
        {
            transform.localScale = new Vector2(Mathf.Sign(rb2d.velocity.x), 1f);
        }
    }
}
